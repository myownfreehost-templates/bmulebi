<html>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'> 
<title>ბმულები</title>
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: #dfdfdf;  
}  
button {   
       box-shadow: 1px 1px 1px 1px #cfcfcf;
       background-color: #efefef;   
       width: 100%;
       font-size: 14px;
        color: black;   
           padding: 10px;
        border: none;  
        border-radius: 20px 20px 20px 20px;
        cursor: pointer;   
         }      
 input[type=url] {   
        width: 100%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid #5f5f5f; 
        border-radius: 15px 15px 15px 15px;
        box-sizing: border-box;
    } 
textarea {   
        width: 100%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid #5f5f5f;
        border-radius: 15px 15px 15px 15px;
        box-sizing: border-box;   
    } 
 button:hover {   
        opacity: 0.6;   
    } 
 .container { 
        box-shadow: 10px 5px 5px 5px #cfcfcf;
        border: 3px solid #fafafa;
        padding: 25px;   
        background-color: #bfbfbf;
        border-radius: 15px 15px 15px 15px;
    }
.link {
display: inline-block;
box-shadow: 1px 1px 1px 1px #efefef;
  background-color: #cfcfcf;
  border-radius: 25px 25px 25px 25px;
  color: blue;
  border: 1px solid #0000ff;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
.word {
display: inline-block;
box-shadow: 1px 1px 1px 1px #efefef;
  background-color: #efefef;
  border-radius: 25px 25px 25px 25px;
  color: gray;
  border: 1px solid #ff0000;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
</style> 
</head>
<body>
<div style="padding: 5px; text-align:center; width: auto; height: auto; border-radius: 15px 15px 15px 15px;"> 
<h1 class='word'><font color='#888888'>bmulebi.com</font> <font color='#afafaf'>ბმულის გაზიარება</font></h1>
</div><br>
 <div class="container"> <center><h4><font class='word' color='#555555'>ბმული</font> <a class='link' href='<?php
echo file_get_contents('link.txt');
?>'><?php
echo file_get_contents('link.txt');
?></a></h4><hr style='color: #cfcfcf;'>
<a class='link' href="https://www.facebook.com/sharer/sharer.php?u=<?php
echo file_get_contents('link.txt');
?>" target="_blank">
<font color='#0000ff'>გაზიარება Facebook-ზე</font></a> <a class='link' href="https://connect.ok.ru/offer?url=<?php
echo file_get_contents('link.txt');
?>" target="_blank">
<font color='#0000ff'>გაზიარება Одноклассники-ზე</font>
</a><hr style='color: #cfcfcf;'>
<center><h4 class='word'>აღწერა</h4> <h4 class='word'><font color='#ff0000'><?php
echo file_get_contents('about.txt');
?></font></h4><br>
</center><br></div><br>
<form action='add.php' method='POST'>
<div class="container"> 
<input type='url' value='http://' placeholder="ბმული" name='link' required><br><textarea rows='5' cols='5' placeholder="ბმულის აღწერა" name='about' required></textarea><br><button type="submit">გაზიარება</button> 
</form></div>
<br>
                <!-- TOP.GE ASYNC COUNTER CODE -->
                <div id="top-ge-counter-container" data-site-id="116726"></div>
                <script async src="//counter.top.ge/counter.js"></script>
                <!-- / END OF TOP.GE COUNTER CODE -->
</body>
</html>

