<html>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'> 
<title>ბმულები</title>
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: #000000;  
}  
button {   
background-color: #000000;
color: #444444;
       box-shadow: 1px 1px 1px 1px #000000;  
       width: 100%;
       font-size: 14px;  
           padding: 10px;
        border: none;  
        border-radius: 20px 20px 20px 20px;
        cursor: pointer;   
         }      
 input[type=url] {  
 background-color: #000000;
color: #444444;
        width: 100%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid #5f5f5f; 
        border-radius: 15px 15px 15px 15px;
        box-sizing: border-box;
    } 
textarea {   
background-color: #000000;
color: #444444;
        width: 100%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid #5f5f5f;
        border-radius: 15px 15px 15px 15px;
        box-sizing: border-box;   
    } 
 button:hover {   
        opacity: 0.6;   
    } 
 .container { 

        border: 3px solid #222222;
        padding: 25px;   
        background-color: #111111;
        border-radius: 15px 15px 15px 15px;
    }
 th { 

        border: 3px solid #333333;
        padding: 5px;
        margin: 5px;
        background-color: #222222;
        border-radius: 15px 15px 15px 15px;
    }
.link {
display: inline-block;
box-shadow: 1px 1px 1px 1px #000000;
  background-color: #cfcfcf;
  border-radius: 25px 25px 25px 25px;
  color: blue;
  border: 1px solid #0000ff;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
.word {
display: inline-block;
box-shadow: 1px 1px 1px 1px #000000;
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: gray;
  border: 1px solid #ff0000;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
.copy {
display: inline-block;
box-shadow: 1px 1px 1px 1px #000000;
  background-color: #efefef;
  border-radius: 5px 5px 5px 5px;
  color: green;
  border: 1px solid green;
  text-decoration:none;
  padding: 5px 5px 5px 5px;
  margin: 5px 5px 5px 5px;
}
</style> 
</head>
<body>
<div style="background-color: #111111; padding: 5px; text-align:left; width: auto; height: auto; border-radius: 15px 15px 15px 15px;"> 
<a class='link' href="/index.php"><?php echo $_SERVER['SERVER_NAME']; ?></a><font class='word'> <font color='#222222'>ბმულის გაზიარება</font></font>
</div><br>
 <div class="container"> <table><tr><th style="position: relative; word-break: break-all; text-decoration:none; display: inline-block;"><center><big><font class='word' color='#555555'>ახალი ბმული</font> <a class='link' href='<?php
echo file_get_contents('link.txt');
?>'><?php
echo file_get_contents('link.txt');
?></a></big></th><th style="position: relative; word-break: break-all; text-decoration:none; display: inline-block;"><script>
function copy() {
  let textarea = document.getElementById("textarea");
  textarea.select();
  document.execCommand("copy");
}
</script>
<big><font class='word' color='#555555'>ბმულის გადატანა</font></big> <input class='copy' type=text id='textarea' value='<?php
echo file_get_contents('link.txt');
?>'>
<input type='submit' value='დაკოპირება' class='link' onclick="copy()"></form></th><th style="position: relative; word-break: break-all; text-decoration:none; display: inline-block;">
<big class='word'>ბმულის აღწერა</big> <font class='word'><font color='#ff0000'><?php
echo file_get_contents('about.txt');
?></font></font></th><th style="position: relative; word-break: break-all; text-decoration:none; display: inline-block;"><big class='word'>გაზიარება</big>
<a class='link' href="https://www.facebook.com/sharer/sharer.php?u=<?php
echo file_get_contents('link.txt');
?>" target="_blank">
<font color='#0000ff'>გაზიარება Facebook-ზე</font></a> <a class='link' href="https://connect.ok.ru/offer?url=<?php
echo file_get_contents('link.txt');
?>" target="_blank">
<font color='#0000ff'>გაზიარება Одноклассники-ზე</font>
</a></th></tr></table>
</center><br></div><br>
<form action='add.php' method='POST'>
<div class="container"> 
<input type='url' value='http://' placeholder="ბმული" name='link' required><br><textarea rows='5' cols='5' placeholder="ბმულის აღწერა" name='about' required></textarea><br><button type="submit">გაზიარება</button> 
</form>
</div>
<div style="background-color: #111111; padding: 5px; text-align:right; width: auto; height: auto; border-radius: 15px 15px 15px 15px;"> 
<small class='word'>&copy; 2022 - <?php $year = date("Y"); echo $year; ?></small>
</div>
<br>
                <!-- TOP.GE ASYNC COUNTER CODE -->
                <div id="top-ge-counter-container" data-site-id="116726"></div>
                <script async src="//counter.top.ge/counter.js"></script>
                <!-- / END OF TOP.GE COUNTER CODE -->
</body>
</html>

