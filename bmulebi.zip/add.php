<?php
$link = $_POST['link'];
$fp = fopen('link.txt', 'w');
fwrite($fp, $link);
fclose($fp);
?>
<?php
$about = $_POST['about'];
$fp = fopen('about.txt', 'w');
fwrite($fp, $about);
fclose($fp);
?>
<html>
<?php
header('Location: index.php');
exit;
?>
